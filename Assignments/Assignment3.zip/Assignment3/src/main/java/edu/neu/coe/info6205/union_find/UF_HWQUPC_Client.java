package edu.neu.coe.info6205.union_find;

import java.util.Random;
import java.util.Scanner;

public class UF_HWQUPC_Client {

    public static int count(int n){
        int connections = 0;
        int generations = 0;
        UF_HWQUPC ufHwqupc = new UF_HWQUPC(n,false);
        Random random = new Random();

        while (ufHwqupc.components() != 1){
            int i = random.nextInt(n);
            int j = random.nextInt(n);
            generations ++;
            if(!ufHwqupc.connected(i,j)){
                ufHwqupc.connect(i,j);
                connections ++;
            }
        }
        return connections;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Input N:");
        int n = input.nextInt();

        int connections= UF_HWQUPC_Client.count(n);
        System.out.printf("There are %d (n) sites, the number of connections is %d",n,connections);

    }

}
