# INFO6205
Assignment2
=============
## Part1<br>
# code:[Timer.java](src/main/java/edu/neu/coe/info6205/util/Timer.java)
# result screenshot:
